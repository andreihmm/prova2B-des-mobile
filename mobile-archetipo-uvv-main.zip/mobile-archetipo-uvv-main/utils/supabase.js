
import { createClient } from '@supabase/supabase-js'
const supabaseUrl = 'https://xfrlsejrveiypqmcidkt.supabase.co'
const supabaseKey = ''
const supabase = createClient(supabaseUrl, supabaseKey)

export default supabase