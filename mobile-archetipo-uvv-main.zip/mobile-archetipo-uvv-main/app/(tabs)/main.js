import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

export default function Main() {
  return (
    <View style={styles.container}>
      <Text style={styles.message}>Under Work</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f7f7f7',
  },
  message: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#023373',
  },
});
