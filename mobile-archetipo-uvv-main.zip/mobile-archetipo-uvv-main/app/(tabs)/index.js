import { useState } from 'react';
import { StyleSheet, View, ImageBackground, TextInput, Text, TouchableOpacity } from 'react-native';
import LogoUVV from '../../components/uvv-components/logoUVV.js';
import supabase from '@/utils/supabase';
import { router } from 'expo-router';

const uvvImagem = require('@/assets/uvv-assets/uvv.jpg');

export default function App() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');

  const handleLogin = async () => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password: senha,
      });

      if (error) throw error;
      router.push('./main'); // Navegação após login bem-sucedido
    } catch (err) {
      setErro(err.message);
    }
  };

  return (
    <ImageBackground source={uvvImagem} resizeMode="cover" style={styles.uvvImagem}>
      <View style={styles.viewInputs}>
        <LogoUVV />
        <View style={styles.viewDigitarDados}>
          <TextInput
            style={styles.inputTexto}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            placeholderTextColor="#ccc"
          />
          <TextInput
            style={styles.inputTexto}
            placeholder="Senha"
            secureTextEntry
            value={senha}
            onChangeText={setSenha}
            placeholderTextColor="#ccc"
          />
          {erro ? <Text style={styles.erroText}>{erro}</Text> : null}
        </View>
        <TouchableOpacity onPress={handleLogin} style={styles.botoes}>
          <Text style={styles.botoesText}>Conectar-se</Text>
        </TouchableOpacity>

        {/* Replaced Link with TouchableOpacity */}
        <TouchableOpacity
          onPress={() => router.push('/RegisterPage')}
          style={styles.botoes}
        >
          <Text style={styles.botoesText}>Registrar</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  uvvImagem: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewInputs: {
    borderRadius: 20,
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    maxHeight: '70%',
    width: '85%',
    alignItems: 'center',
    justifyContent: 'space-around',
    padding: 20,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 8,
  },
  viewDigitarDados: {
    width: '100%',
    backgroundColor: 'rgba(247,194,34,0.9)',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 12,
    justifyContent: 'space-around',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  inputTexto: {
    backgroundColor: 'white',
    borderColor: '#ddd',
    borderBottomWidth: 1.5,
    width: '100%',
    height: 50,
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
  },
  botoes: {
    borderRadius: 10,
    backgroundColor: '#023373', // Button background color
    width: '80%',
    paddingVertical: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
    marginBottom: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  botoesText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
  },
  erroText: {
    color: 'red',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 10,
    fontWeight: '500',
  },
});
