import { useState } from 'react';
import { StyleSheet, View, ImageBackground, TextInput, Text, TouchableOpacity } from 'react-native';
import { Link } from '@react-navigation/native';
import LogoUVV from '../../components/uvv-components/logoUVV.js';
import supabase from '@/utils/supabase';
import { router } from 'expo-router';

const uvvImagem = require('@/assets/uvv-assets/uvv.jpg');

export default function App() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);

  const handleRegister = async () => {
    setErro('');
    try {
      setCarregando(true);

      // Criação do usuário com o e-mail e senha no Supabase
      const { data, error } = await supabase.auth.signUp({
        email,
        password: senha,
      });

      if (error) throw error;

      // Caso o registro seja bem-sucedido, navega para a tela de login
      router.push('/'); // Navega para a tela de login
    } catch (err) {
      setErro('Erro ao criar conta: ' + err.message);
    } finally {
      setCarregando(false);
    }
  };

  return (
    <ImageBackground source={uvvImagem} resizeMode="cover" style={styles.uvvImagem}>
      <View style={styles.viewInputs}>
        <LogoUVV />
        <View style={styles.viewDigitarDados}>
          <TextInput
            style={styles.inputTexto}
            placeholder="E-mail"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            placeholderTextColor="#888"
          />
          <TextInput
            style={styles.inputTexto}
            placeholder="Senha"
            secureTextEntry
            value={senha}
            onChangeText={setSenha}
            placeholderTextColor="#888"
          />
          {erro ? <Text style={styles.erroText}>{erro}</Text> : null}
        </View>

        <TouchableOpacity onPress={handleRegister} style={[styles.botoes, carregando && styles.botoesDisabled]} disabled={carregando}>
          <Text style={styles.botoesText}>
            {carregando ? 'Criando conta...' : 'Criar conta'}
          </Text>
        </TouchableOpacity>

        <Link to="/" style={styles.botoes}>
          <Text style={styles.botoesText}>Já tem uma conta? Fazer login</Text>
        </Link>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  uvvImagem: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewInputs: {
    borderRadius: 20,
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    maxHeight: '75%',
    width: '85%',
    alignItems: 'center',
    justifyContent: 'space-around',
    padding: 20,
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 15,
    elevation: 8,
  },
  viewDigitarDados: {
    width: '100%',
    backgroundColor: 'rgba(247,194,34,0.9)',
    paddingVertical: 20,
    paddingHorizontal: 25,
    borderRadius: 15,
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  inputTexto: {
    backgroundColor: 'white',
    borderColor: '#ddd',
    borderBottomWidth: 1.5,
    width: '100%',
    height: 50,
    borderRadius: 10,
    marginBottom: 20,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
    marginTop: 10,
  },
  botoes: {
    borderRadius: 10,
    backgroundColor: '#023373',
    width: '80%',
    paddingVertical: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  botoesText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
  },
  botoesDisabled: {
    backgroundColor: '#ccc',
  },
  erroText: {
    color: 'red',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 15,
    fontWeight: '500',
  },
});
